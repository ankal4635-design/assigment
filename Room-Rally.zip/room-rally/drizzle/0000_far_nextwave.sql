CREATE TABLE `answers` (
	`room` text NOT NULL,
	`player` text NOT NULL,
	`round` integer NOT NULL,
	`choice` integer NOT NULL,
	`points` integer NOT NULL,
	`elapsed` integer NOT NULL,
	PRIMARY KEY(`room`, `player`, `round`),
	FOREIGN KEY (`room`) REFERENCES `rooms`(`code`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`player`) REFERENCES `players`(`token`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `players` (
	`token` text PRIMARY KEY NOT NULL,
	`room` text NOT NULL,
	`name` text NOT NULL,
	`avatar` integer NOT NULL,
	`joined` integer NOT NULL,
	FOREIGN KEY (`room`) REFERENCES `rooms`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`topic` text NOT NULL,
	`questions` text NOT NULL,
	`seconds` integer NOT NULL,
	`started` integer,
	`created` integer NOT NULL
);
