# Room Rally

A Kahoot-style quiz for 2–8 friends and family, built for ChatGPT Sites. Everyone uses their own browser or ChatGPT's built-in browser. One host creates a room and shares the link and six-character room code.

## Rules

Choose a built-in quiz (Mixed bag, Science, or World), 5 or 10 questions, and a 10-, 20-, or 30-second answer window. The host starts after at least two people have joined. Questions and choices are shuffled on the server. Each correct answer earns `round(1000 - 500 × elapsed / questionDuration)` points; incorrect answers earn zero. The first submission is final. Highest total score wins; exact ties share victory. A 6.5-second reveal follows each question. The host can start a rematch with a fresh shuffle.

## Shared state

Cloudflare D1 stores rooms, players, and answers. The server owns the start timestamp, round deadlines, answer keys, and scoring. Clients fetch shared state every 800 milliseconds and correct their displayed clocks using server time; network delays can affect points. Answers are unique per player per round, and a single SQL statement enforces the eight-player room capacity. Host credentials stay in the current tab's session storage and are never shared with other players. Refreshing the tab restores the current player. Closing the tab or leaving its screen loses that player credential; create a fresh room if the host leaves. Disconnected players remain on the room roster. Rooms expire after 24 hours and expired rooms are removed on the next room creation.

Hosting audience controls determine who may open the site; room codes determine which game an allowed visitor joins. New Sites are private until the owner chooses a wider audience.

## Development

Requires Node.js 22.13 or newer. Install dependencies using the Sites skill's installer or `npm run install:ci`. Generate a new migration with `npm run db:generate` after schema changes. Build with `npm run build`, apply migrations to local D1 as described in the Sites starter, and use `npm start` to preview the built Worker. Run the game integration tests using:

```sh
node --experimental-strip-types --test tests/*.test.mjs
npx tsc --noEmit
```

The test suite uses SQLite with the real generated SQL migrations and multiple independent player credentials. It checks speed scoring, round synchronisation, hidden answers, duplicate submissions, late submissions, host permissions, room capacity, room expiry, and rematch reset.

`.openai/hosting.json` retains the Site identity and D1 binding. Never commit runtime state, credentials, or build output. Publish through the Sites source and deployment workflow.

## QR invitations and phone testing

Every room lobby displays a QR code containing its invitation link and room code. Players can scan it with their phone’s Camera app. The join form also has a scanner with camera and local image-upload options. A scan fills the room code; the player still enters a nickname and joins. “Save QR code” downloads a PNG. Images are decoded locally. Room credentials are never included in the QR code. Invites from another server are rejected by the in-app scanner to avoid joining a room on the wrong server.

To test on phones connected to the computer’s Wi-Fi, run:

```sh
npm run dev -- --hostname 0.0.0.0 --port 5173
```

Open the computer’s LAN address (for example `http://192.168.100.158:5173`) on the host computer **before creating the room**, so the QR uses an address the phones can reach. Do not use a localhost QR on another device. Allow port 5173 through your local firewall if needed; Wi-Fi client isolation can prevent connections. The LAN server uses the same local D1 database as the loopback preview. Keep the server running while playing.

The in-app camera scanner requires a browser connection that permits camera access (normally HTTPS or localhost). On a LAN HTTP address, scan with the phone’s native Camera app or use “Upload QR image.” The hosted HTTPS Site supports the in-app camera when browser permissions allow it. Its existing hosting audience still controls who can open it.

With the server running, exercise two players over its real LAN interface using:

```sh
ROOM_RALLY_TEST_ORIGIN=http://192.168.100.158:5173 node --experimental-strip-types tests/http-smoke.mjs
```
