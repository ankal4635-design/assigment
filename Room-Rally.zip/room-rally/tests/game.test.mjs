import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { gameAction, getState } from '../lib/game.ts';
function database() {
 const sqlite = new DatabaseSync(':memory:');
 sqlite.exec('PRAGMA foreign_keys = ON');
 for (const f of readdirSync(new URL('../drizzle/', import.meta.url)).filter(f => f.endsWith('.sql')).sort()) {
  sqlite.exec(readFileSync(new URL('../drizzle/' + f, import.meta.url), 'utf8'));
 }
 const prepare = sql => {
  let args = [];
  const statement = {
   bind: (...values) => { args = values; return statement; },
   first: async () => sqlite.prepare(sql).get(...args) ?? null,
   all: async () => ({ results: sqlite.prepare(sql).all(...args) }),
   run: async () => ({ meta: { changes: sqlite.prepare(sql).run(...args).changes } }),
  }; return statement;
 };
 return { prepare, batch: async statements => {
  sqlite.exec('BEGIN'); try { const result = []; for (const s of statements) result.push(await s.run()); sqlite.exec('COMMIT'); return result; }
  catch (e) { sqlite.exec('ROLLBACK'); throw e; }
 }, sqlite };
}
const now = 1800000000000;
const create = db => gameAction(db, { action: 'create', name: 'Host', topic: 'Science', rounds: 5, seconds: 10 }, '', now);
test('two clients share rounds; fastest correct answer wins; answers stay secret until reveal', async () => {
 const db = database(); const host = await create(db);
 await assert.rejects(() => gameAction(db, { action: 'start', code: host.code }, host.token, now), /At least two/);
 const friend = await gameAction(db, { action: 'join', code: host.code, name: 'Friend' }, '', now + 1);
 await assert.rejects(() => gameAction(db, { action: 'start', code: host.code }, friend.token, now), /Only the host/);
 const countdown = await gameAction(db, { action: 'start', code: host.code }, host.token, now + 100);
 assert.equal(countdown.phase, 'countdown');
 const start = countdown.phaseEnds;
 await assert.rejects(() => gameAction(db, { action: 'answer', code: host.code, round: 0, choice: 0 }, host.token, start - 1), /window has closed/);
 await assert.rejects(() => gameAction(db, { action: 'join', code: host.code, name: 'Late' }, '', start), /has started/);
 const a = await getState(db, host.code, host.token, start + 1);
 const b = await getState(db, host.code, friend.token, start + 1);
 assert.deepEqual(a.question, b.question); assert.equal(a.phaseEnds, b.phaseEnds);
 assert.equal(a.question.correct, undefined); assert.equal(a.question.explanation, undefined);
 assert.ok(!JSON.stringify(a).includes(friend.token));
 const questions = JSON.parse(db.sqlite.prepare('SELECT questions FROM rooms').get().questions);
 for (let round = 0; round < 5; round++) {
  const begins = start + round * 16500;
  const choice = questions[round].correct;
  await gameAction(db, { action: 'answer', code: host.code, round, choice, points: 999999 }, host.token, begins + 100);
  await gameAction(db, { action: 'answer', code: host.code, round, choice }, friend.token, begins + 5000);
  const repeat = await gameAction(db, { action: 'answer', code: host.code, round, choice: (choice + 1) % 4 }, host.token, begins + 5001);
  assert.equal(repeat.submitted, choice);
  await assert.rejects(() => gameAction(db, { action: 'answer', code: host.code, round: round + 1, choice }, host.token, begins + 5002), /another question/);
  const reveal = await getState(db, host.code, host.token, begins + 10000);
  assert.equal(reveal.phase, 'reveal'); assert.equal(reveal.question.correct, choice);
  assert.equal(reveal.players.find(p => p.name === 'Host').score, 995 * (round + 1));
  assert.equal(reveal.players.find(p => p.name === 'Friend').score, 750 * (round + 1));
  await assert.rejects(() => gameAction(db, { action: 'answer', code: host.code, round, choice }, host.token, begins + 10000), /window has closed/);
 }
 const end = start + 5 * 16500;
 const final = await getState(db, host.code, host.token, end);
 assert.equal(final.phase, 'finished'); assert.equal(final.players[0].score, 4975);
 assert.equal(final.players[1].score, 3750); assert.equal(final.players[0].correct, 5);
 await assert.rejects(() => gameAction(db, { action: 'replay', code: host.code }, friend.token, end), /Only the host/);
 const replay = await gameAction(db, { action: 'replay', code: host.code }, host.token, end);
 assert.equal(replay.phase, 'lobby'); assert.equal(replay.players.length, 2); assert.equal(replay.players[0].score, 0);
 assert.equal(replay.submitted, null);
});
test('room cap holds for concurrent joins, names are unique, and credentials are required', async () => {
 const db = database(); const host = await create(db);
 const joins = await Promise.allSettled(Array.from({ length: 12 }, (_, i) => gameAction(db, { action: 'join', code: host.code, name: 'Guest' + i }, '', now + 1)));
 assert.equal(joins.filter(r => r.status === 'fulfilled').length, 7);
 const state = await getState(db, host.code, host.token, now + 2); assert.equal(state.players.length, 8);
 await assert.rejects(() => getState(db, host.code, 'bad-token', now), /rejoin/);
 await assert.rejects(() => getState(db, host.code, host.token, now + 86400001), /expired/);
 const db2 = database(); const h2 = await create(db2);
 await assert.rejects(() => gameAction(db2, { action: 'join', code: h2.code, name: 'host' }, '', now), /name already taken/);
 await assert.rejects(() => gameAction(db2, { action: 'create', name: 'Test', topic: '__proto__' }, '', now), /quiz topic/);
});
test('wrong answers score zero; simultaneous submissions only count once', async () => {
 const db = database(); const host = await create(db);
 const friend = await gameAction(db, { action: 'join', code: host.code, name: 'Friend' }, '', now + 1);
 const started = await gameAction(db, { action: 'start', code: host.code }, host.token, now + 2);
 const qs = JSON.parse(db.sqlite.prepare('SELECT questions FROM rooms').get().questions);
 await Promise.all(Array.from({ length: 6 }, () => gameAction(db, { action: 'answer', code: host.code, round: 0, choice: (qs[0].correct + 1) % 4 }, friend.token, started.phaseEnds + 300)));
 assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS total FROM answers').get().total, 1);
 const state = await getState(db, host.code, friend.token, started.phaseEnds + 10000);
 assert.equal(state.players.find(p => p.name === 'Friend').score, 0);
});
