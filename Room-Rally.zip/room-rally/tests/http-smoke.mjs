import assert from 'node:assert/strict';
import { bank } from '../lib/questions.ts';
const origin = process.env.ROOM_RALLY_TEST_ORIGIN || 'http://127.0.0.1:4173';
const delay = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
async function post(input, token = '', requestOrigin = origin) {
 const response = await fetch(origin + '/api/game', { method: 'POST', headers: { 'content-type': 'application/json', 'x-player-token': token, origin: requestOrigin }, body: JSON.stringify(input) });
 const text = await response.text();
 let data; try { data = JSON.parse(text); } catch { data = { error: text }; }
 return { status: response.status, data };
}
async function state(session) {
 const r = await fetch(origin + '/api/game?code=' + session.code, { headers: { 'x-player-token': session.token } });
 assert.equal(r.status, 200); return r.json();
}
const page = await fetch(origin); assert.equal(page.status, 200); assert.match(await page.text(), /Great guesses/);
assert.equal((await post({ action: 'create', name: 'Blocked' }, '', 'https://other.example')).status, 403);
const hostResponse = await post({ action: 'create', name: 'Host', topic: 'Science', rounds: 5, seconds: 10 });
assert.equal(hostResponse.status, 200); const host = hostResponse.data;
const guestResponse = await post({ action: 'join', code: host.code, name: 'Guest' });
assert.equal(guestResponse.status, 200); const guest = guestResponse.data;
assert.equal((await state(host)).players.length, 2);
assert.equal((await post({ action: 'start', code: host.code }, guest.token)).status, 403);
const started = await post({ action: 'start', code: host.code }, host.token);
assert.equal(started.status, 200); assert.equal(started.data.phase, 'countdown');
await delay(started.data.phaseEnds - Date.now() + 100);
const [h, g] = await Promise.all([state(host), state(guest)]);
assert.equal(h.phase, 'question'); assert.deepEqual(h.question, g.question); assert.equal(h.phaseEnds, g.phaseEnds);
assert.equal(h.question.correct, undefined);
const original = bank.Science.find(q => q.text === h.question.text);
const correct = h.question.options.indexOf(original.options[original.correct]);
const first = await post({ action: 'answer', code: host.code, round: 0, choice: correct }, host.token);
assert.equal(first.status, 200); assert.equal(first.data.submitted, correct);
await delay(1300);
assert.equal((await post({ action: 'answer', code: guest.code, round: 0, choice: correct }, guest.token)).status, 200);
await delay(h.phaseEnds - Date.now() + 100);
const reveal = await state(host);
assert.equal(reveal.phase, 'reveal'); assert.equal(reveal.question.correct, correct);
const hScore = reveal.players.find(p => p.name === 'Host').score;
const gScore = reveal.players.find(p => p.name === 'Guest').score;
assert.ok(hScore > gScore && gScore >= 500);
assert.equal((await post({ action: 'answer', code: host.code, round: 0, choice: correct }, host.token)).status, 400);
await delay(reveal.phaseEnds - Date.now() + 100);
const next = await state(guest); assert.equal(next.phase, 'question'); assert.equal(next.round, 1); assert.equal(next.submitted, null);
console.log('HTTP smoke passed: home page, two players, host permissions, shared timer, secret answers, speed scoring, late-answer rejection, and next-round sync.');
