import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { QRCodeSVG } from 'qrcode.react';
import jsQR from 'jsqr';
// Sharp is already installed by the starter's local Worker runtime.
import sharp from 'sharp';
import { createInviteUrl, parseRoomInvite } from '../lib/invite.ts';

test('QR codes round-trip through the decoder for LAN and hosted rooms', async () => {
 for (const origin of ['http://192.168.100.158:5173', 'https://room-rally-ankal.zestygull9.chatgpt.site']) {
  const code = 'ABC234'; const url = createInviteUrl(origin, code);
  const image = renderToStaticMarkup(createElement(QRCodeSVG, { value: url, size: 192, level: 'M', marginSize: 4, fgColor: '#252326', bgColor: '#ffffff' }));
  const { data, info } = await sharp(Buffer.from(image)).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const decoded = jsQR(new Uint8ClampedArray(data), info.width, info.height);
  assert.ok(decoded, 'QR code must be readable at its displayed size');
  assert.equal(decoded.data, url); assert.equal(parseRoomInvite(decoded.data, origin), code);
  const parsed = new URL(url); assert.equal(parsed.hash, '#join-room');
  assert.deepEqual([...parsed.searchParams.keys()], ['room']);
 }
});
test('scanning accepts room codes and rejects invalid or unrelated invitations', () => {
 const origin = 'https://game.example';
 assert.equal(parseRoomInvite(' abc234 ', origin), 'ABC234');
 assert.equal(parseRoomInvite('https://game.example/?room=abc234#join-room', origin), 'ABC234');
 assert.throws(() => parseRoomInvite('https://other.example/?room=ABC234', origin), /different game server/);
 assert.throws(() => parseRoomInvite('javascript:alert(1)', origin), /not a Room Rally invitation/);
 assert.throws(() => parseRoomInvite('https://user:password@game.example/?room=ABC234', origin), /not a Room Rally invitation/);
 assert.throws(() => parseRoomInvite('https://game.example/other?room=ABC234', origin), /valid room code/);
 assert.throws(() => parseRoomInvite('https://game.example/?room=123', origin), /valid room code/);
 assert.throws(() => createInviteUrl(origin, 'invalid'), /Invalid room code/);
 assert.throws(() => createInviteUrl('javascript:alert(1)', 'ABC234'));
});
