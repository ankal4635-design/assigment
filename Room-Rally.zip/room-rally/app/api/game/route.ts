import { env } from 'cloudflare:workers';
import { gameAction, GameError, getState } from '@/lib/game';
export const dynamic = 'force-dynamic';
const reply = (data: unknown, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store, private', 'Vary': 'X-Player-Token' } });
function failure(error: unknown) {
 if (error instanceof GameError) return reply({ error: error.message }, error.status);
 console.error('Game request failed', error); return reply({ error: 'The game server could not respond. Please try again.' }, 500);
}
export async function GET(request: Request) {
 try {
  const code = new URL(request.url).searchParams.get('code') ?? '';
  if (!/^[A-Z2-9]{6}$/.test(code)) throw new GameError('Enter a valid room code.');
  return reply(await getState(env.DB!, code, request.headers.get('x-player-token') ?? ''));
 } catch (error) { return failure(error); }
}
export async function POST(request: Request) {
 try {
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) throw new GameError('Open the game directly to play.', 403);
  if (!request.headers.get('content-type')?.includes('application/json')) throw new GameError('Expected a game request.');
  const raw = await request.text(); if (raw.length > 4000) throw new GameError('Request too large.');
  let input; try { input = JSON.parse(raw); } catch { throw new GameError('Invalid game request.'); }
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new GameError('Invalid game request.');
  return reply(await gameAction(env.DB!, input, request.headers.get('x-player-token') ?? ''));
 } catch (error) { return failure(error); }
}
