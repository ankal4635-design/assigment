import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Room Rally — Good company. Great guesses.",
  description: "A fast, friendly multiplayer quiz. Share a room code and race to the right answer.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
