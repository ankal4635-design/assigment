'use client';
import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Check, Copy, Crown, Flag, HelpCircle, LogOut, Plus, QrCode, Sparkles, Timer, Trophy, Users, X, Zap } from 'lucide-react';
import { RoomQR } from '@/components/room-qr';
import { QRScanner } from '@/components/qr-scanner';
import { createInviteUrl } from '@/lib/invite';
import type { GameState, Session } from '@/lib/types';
const avatars = ['🦊', '🐼', '🐸', '🐯', '🐙', '🦁', '🐨', '🐻'];
const symbols = ['▲', '◆', '●', '■'];
const STORAGE = 'room-rally-session';
export default function Home() {
 const [session, setSession] = useState<Session | null>(null);
 const [game, setGame] = useState<GameState | null>(null);
 const [name, setName] = useState(''); const [code, setCode] = useState('');
 const [topic, setTopic] = useState('Mixed bag'); const [rounds, setRounds] = useState(5); const [seconds, setSeconds] = useState(20);
 const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [help, setHelp] = useState(false);
 const [copied, setCopied] = useState(false); const [online, setOnline] = useState(true);
 const [scanning, setScanning] = useState(false); const [scanned, setScanned] = useState(false);
 const joinName = useRef<HTMLInputElement>(null);
 const [clock, setClock] = useState(Date.now()); const offset = useRef(0); const generation = useRef(0);
 const pollController = useRef<AbortController | null>(null);
 useEffect(() => {
  if (!help) return;
  const onKey = (event: KeyboardEvent) => {
   if (event.key === 'Escape') setHelp(false);
   if (event.key === 'Tab') {
    const buttons = document.querySelectorAll<HTMLButtonElement>('.help-modal button');
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
   }
  };
  document.addEventListener('keydown', onKey); return () => document.removeEventListener('keydown', onKey);
 }, [help]);
 useEffect(() => {
  try { const saved = sessionStorage.getItem(STORAGE); if (saved) setSession(JSON.parse(saved)); } catch {}
  const c = new URL(location.href).searchParams.get('room');
  if (c && /^[A-Z2-9]{6}$/.test(c.toUpperCase())) {
   setCode(c.toUpperCase()); setScanned(true);
   requestAnimationFrame(() => { document.getElementById('join-room')?.scrollIntoView({ block: 'start' }); joinName.current?.focus({ preventScroll: true }); });
  }
  const ticker = setInterval(() => setClock(Date.now()), 100); return () => clearInterval(ticker);
 }, []);
 function accept(data: GameState, sent: number) { offset.current = data.serverNow - (sent + Date.now()) / 2; setGame(data); setOnline(true); }
 useEffect(() => {
  if (!session) return;
  let cancelled = false; let timer: ReturnType<typeof setTimeout>;
  const poll = async () => {
   const version = generation.current; const sent = Date.now(); const controller = new AbortController(); pollController.current = controller;
   const timeout = setTimeout(() => controller.abort(), 8000);
   try {
    const response = await fetch('/api/game?code=' + session.code, { headers: { 'x-player-token': session.token }, cache: 'no-store', signal: controller.signal });
    const data = await response.json() as GameState | { error: string };
    if (!cancelled && version === generation.current) {
     if (!response.ok || 'error' in data) { setError('error' in data ? data.error : 'Could not load your room.'); setOnline(false); } else accept(data, sent);
    }
   } catch { if (!cancelled && version === generation.current) setOnline(false); }
   finally { clearTimeout(timeout); if (!cancelled) timer = setTimeout(poll, 800); }
  };
  poll(); return () => { cancelled = true; clearTimeout(timer); pollController.current?.abort(); };
 }, [session]);
 async function action(actionName: string, extra: Record<string, unknown> = {}) {
  if (busy) return; setBusy(true); setError(''); generation.current++; pollController.current?.abort();
  const sent = Date.now();
  try {
   const response = await fetch('/api/game', { method: 'POST', headers: { 'Content-Type': 'application/json', ...(session ? { 'x-player-token': session.token } : {}) },
    body: JSON.stringify({ action: actionName, code: session?.code ?? code, name, topic, rounds, seconds, ...extra }), signal: AbortSignal.timeout(10000) });
   const data = await response.json() as GameState | Session | { error: string };
   if (!response.ok || 'error' in data) throw new Error('error' in data ? data.error : 'Please try again.');
   if (actionName === 'create' || actionName === 'join') {
    try { sessionStorage.setItem(STORAGE, JSON.stringify(data)); } catch {} setSession(data as Session); setGame(null);
   } else { generation.current++; accept(data as GameState, sent); }
  } catch (err) { setError(err instanceof Error ? err.message : 'Connection lost. Please try again.'); }
  finally { setBusy(false); }
 }
 function leave() {
  generation.current++; setSession(null); setGame(null); setError('');
  try { sessionStorage.removeItem(STORAGE); } catch {}
  history.replaceState(null, '', location.pathname);
 }
 async function copyInvite() {
  if (!session) return;
  const invite = createInviteUrl(location.origin, session.code);
  try {
   if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(invite);
   else {
    const textarea = document.createElement('textarea'); textarea.value = invite; textarea.style.position = 'fixed'; textarea.style.opacity = '0'; document.body.appendChild(textarea);
    let copied = false; try { textarea.select(); copied = document.execCommand('copy'); } finally { textarea.remove(); }
    if (!copied) throw new Error('Clipboard unavailable.');
   }
   setCopied(true); setTimeout(() => setCopied(false), 2500);
  } catch { setError('Could not copy automatically. Scan the room QR code or share this link: ' + invite); }
 }
 const me = game?.players.find(p => p.id === game.me);
 const timeLeft = game ? Math.max(0, (game.phaseEnds - clock - offset.current) / 1000) : 0;
 const ranking = game ? [...game.players].sort((a, b) => b.score - a.score || a.id - b.id) : [];
 const isQuestion = game?.phase === 'question'; const isReveal = game?.phase === 'reveal';
 const locked = !isQuestion || game?.submitted !== null || timeLeft <= 0 || !online;
 return <div className="site-shell">
  <header className="topbar"><a className="brand" href="/" aria-label="Room Rally home"><span className="brand-mark"><Zap size={23} fill="currentColor" /></span>room<span>rally</span><span className="brand-dot">✳</span></a>
   <div className="header-right"><span className="together"><i /> MADE FOR YOUR PEOPLE</span><button className="icon-button" aria-label="How to play" onClick={() => setHelp(true)}><HelpCircle size={21} /></button></div>
  </header>
  {!session ? <main>
   <section className="hero"><div className="hero-copy"><div className="eyebrow"><span>SMALL GROUP. BIG GAME ENERGY.</span><Sparkles size={16} /></div>
    <h1>Good company.<br /><span>Great guesses.</span></h1>
    <p>Bring your favourite people. Race to the right answer.<br className="desktop-break" /> A little friendly competition goes a long way.</p>
    <div className="hero-details"><span><Users size={17} /> 2–8 players</span><span><Timer size={17} /> Quick rounds</span><span><Zap size={17} /> Faster = more points</span></div>
   </div><div className="hero-art" aria-label="A playful preview of a quiz question and friendly competition">
    <span className="spark spark-one">✳</span><span className="spark spark-two">✦</span><div className="orbit orbit-one" /><div className="orbit orbit-two" />
    <div className="float-player fox">🦊 <span>You’re on fire! <b>+980</b></span></div>
    <div className="preview-card"><div className="preview-top"><span><i /> QUICK THINKING CLUB</span><span>01 / 05</span></div><div className="preview-icon">⚡</div><h2>Who’s the quickest<br />thinker in your crew?</h2><div className="preview-answers"><span>▲ Let’s find out</span><span>◆ Game on!</span><span>● Pick me</span><span>■ All of us</span></div></div>
    <div className="float-player frog">🐸 <span>Challenge accepted.</span></div><div className="art-caption">A good time is just a room code away. <span>↗</span></div>
   </div></section>
   <section className="play-area" aria-label="Start or join a game">
    <form className="host-card" onSubmit={e => { e.preventDefault(); action('create'); }}><div className="card-heading"><span className="section-icon"><Plus size={22} /></span><span className="tiny-label">BE THE HOST</span><span className="card-number">01</span></div><h2>Your room. Your rules.</h2><p>Pick a quiz, invite your people, and let the rally begin.</p>
     <label>Your player name<input value={name} onChange={e => setName(e.target.value)} required maxLength={20} placeholder="What should we call you?" autoComplete="nickname" /></label>
     <fieldset><legend>Pick your quiz</legend><div className="topic-picker">{['Mixed bag', 'Science', 'World'].map((v, i) => <button type="button" className={topic === v ? 'selected' : ''} onClick={() => setTopic(v)} key={v}>{['🎲', '🧪', '🌍'][i]} {v}</button>)}</div></fieldset>
     <div className="settings-row"><label>Questions<select value={rounds} onChange={e => setRounds(Number(e.target.value))}><option value={5}>5 questions</option><option value={10}>10 questions</option></select></label><label>Time per question<select value={seconds} onChange={e => setSeconds(Number(e.target.value))}><option value={10}>10 seconds</option><option value={20}>20 seconds</option><option value={30}>30 seconds</option></select></label></div>
     <button className="button primary" disabled={busy}>{busy ? 'Just a moment…' : 'Create a room'}<ArrowRight size={19} /></button><span className="under-button">You’ll get a code to share with your crew.</span>
    </form>
    <form className="join-card" id="join-room" onSubmit={e => { e.preventDefault(); action('join'); }}><div className="card-heading"><span className="section-icon join-icon"><Users size={22} /></span><span className="tiny-label">JOIN THE FUN</span><span className="card-number">02</span></div><h2>Got an invite?</h2><p>Your friends are one little code away.</p>
     <label>Your player name<input value={name} onChange={e => setName(e.target.value)} required maxLength={20} ref={joinName} placeholder="Your legendary nickname" autoComplete="nickname" /></label>
     <label>Room code<input className="code-input" value={code} onChange={e => setCode(e.target.value.toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 6))} required minLength={6} maxLength={6} placeholder="ABC234" autoComplete="off" spellCheck={false} /></label>
     <button type="button" className="button scan-button" onClick={() => { setError(''); setScanning(true); }}><QrCode size={19} /> Scan QR code</button>
     {scanned && <p className="scan-success" role="status"><Check size={15} /> Room code ready. Enter your name and join.</p>}
     <div className="join-note"><span>👋</span><p>Everyone plays on their own device.<br />Same questions. Same countdown. All together.</p></div>
     <button className="button dark" disabled={busy}>{busy ? 'Just a moment…' : 'Join a room'}<ArrowRight size={19} /></button><span className="under-button">No downloads. Just bring your best guesses.</span>
    </form>
   </section>
   {error && <div className="error home-error" role="alert">{error}</div>}
   <section className="how-strip"><div><span>01</span><p><b>Round up your people</b>Share a link and your room code.</p></div><div><span>02</span><p><b>Think fast. Tap faster.</b>Correct + quick = more points.</p></div><div><span>03</span><p><b>Claim your bragging rights</b>One leaderboard. Plenty of rematches.</p></div></section>
  </main> : <main className="room-main">
   <div className="room-toolbar"><div><span className="eyebrow">YOUR LITTLE CORNER OF COMPETITION</span><h1>{game?.phase === 'finished' ? 'That’s a rally!' : game?.phase === 'lobby' || !game ? 'The gathering place.' : 'Ready. Set. Rally.'}</h1></div><button className="button subtle" onClick={leave}><LogOut size={16} /> Leave screen</button></div>
   <div className="room-layout"><section className="game-stage">
    <div className="stage-toolbar"><span className="topic-badge">{game?.topic ?? 'Your room'}</span><span className={'connection ' + (!online ? 'offline' : '')}><i />{online ? 'Live room' : 'Reconnecting…'}</span></div>
    {!game ? <div className="center-stage"><span className="big-emoji">⚡</span><h2>Finding your room…</h2><p>{error || 'Getting everyone on the same page.'}</p>{error && <button className="button dark" onClick={leave}>Back to home</button>}</div> : game.phase === 'lobby' ? <div className="lobby">
     <span className="big-emoji">🎉</span><h2>The more, the merrier.</h2><p>Share the link and code. Your crew joins from their own devices.</p>
     <div className="invite-box"><span>YOUR ROOM CODE</span><strong>{game.code}</strong><RoomQR code={game.code} /><button className="button primary" onClick={copyInvite}>{copied ? <Check size={18} /> : <Copy size={18} />}{copied ? 'Invite copied!' : 'Copy invite link'}</button></div>
     <div className="player-bubbles">{game.players.map(p => <div key={p.id}><span>{avatars[p.avatar % 8]}</span><b>{p.name}{p.id === game.me ? ' (you)' : ''}</b>{p.id === 0 && <small>HOST</small>}</div>)}{game.players.length < 8 && <div className="empty-player"><span>+</span><b>Room for more</b></div>}</div>
     <p className="game-settings">{game.total} questions <span>·</span> {game.seconds}s per question <span>·</span> Speed earns points</p>
     {game.host ? <button className="button dark start-button" disabled={game.players.length < 2 || busy || !online} onClick={() => action('start')}>{game.players.length < 2 ? 'Waiting for one more player…' : 'Everyone’s here. Let’s play!'}<ArrowRight size={19} /></button> : <p className="waiting"><span className="pulse-dot" /> Your host will start the game. Get those fingers ready.</p>}
    </div> : game.phase === 'countdown' ? <div className="center-stage countdown"><span className="eyebrow">ALL TOGETHER NOW</span><strong>{Math.max(1, Math.ceil(timeLeft))}</strong><h2>Fast fingers. Sharp minds.</h2><p>Your first question is coming up.</p></div> : game.phase === 'finished' ? <div className="results center-stage"><span className="big-emoji">🏆</span><span className="eyebrow">THE BRAGGING RIGHTS GO TO</span><h2>{ranking.filter(p => p.score === ranking[0]?.score).map(p => p.name).join(' & ')}</h2><p>{ranking.filter(p => p.score === ranking[0]?.score).length > 1 ? 'A shared victory!' : 'A rally well played.'} {ranking[0]?.score.toLocaleString()} points.</p><div className="podium">{ranking.slice(0, 3).map((p, i) => <div key={p.id}><span>{avatars[p.avatar % 8]}</span><b>{i + 1}. {p.name}</b><strong>{p.score.toLocaleString()}</strong><small>{p.correct} / {game.total} correct</small></div>)}</div><div className="personal-result">You scored <b>{me?.score.toLocaleString()} points</b> with {me?.correct} correct answers.</div>{game.host ? <button className="button primary" disabled={busy || !online} onClick={() => action('replay')}>Let’s have a rematch<ArrowRight size={18} /></button> : <p className="waiting">Waiting for your host to set up a rematch.</p>}</div> : <div className="question-stage">
     <div className="question-meta"><span>QUESTION {game.round + 1} <span className="muted">/ {game.total}</span></span><span className={'timer ' + (timeLeft < 6 && isQuestion ? 'urgent' : '')}><Timer size={19} />{Math.ceil(timeLeft)}<small>s</small></span></div>
     <div className="timer-track"><div style={{ width: Math.max(0, Math.min(100, timeLeft / (isQuestion ? game.seconds : 6.5) * 100)) + '%' }} /></div>
     <h2>{game.question?.text}</h2><div className="answer-grid">{game.question?.options.map((option, i) => <button key={i} className={'answer answer-' + i + (game.submitted === i ? ' chosen' : '') + (isReveal && game.question?.correct === i ? ' correct' : '') + (isReveal && game.question?.correct !== i ? ' incorrect' : '')} disabled={locked || busy} onClick={() => action('answer', { choice: i, round: game.round })}><span>{symbols[i]}</span><b>{option}</b>{game.submitted === i && <Check size={21} />}{isReveal && game.question?.correct === i && game.submitted !== i && <Check size={21} />}</button>)}</div>
     <div className="round-feedback" aria-live="polite">{isReveal ? <><b>{game.submitted === null ? 'Time’s up!' : game.submitted === game.question?.correct ? 'Nailed it! +' + me?.lastPoints + ' points' : 'Good try. The next one is yours.'}</b><p>{game.question?.explanation}</p><small>{game.round === game.total - 1 ? 'Final results' : 'Next question'} in {Math.ceil(timeLeft)}s</small></> : <><b>{game.submitted !== null ? 'Answer locked. Nice hustle!' : timeLeft <= 0 ? 'Time’s up! Syncing results…' : 'Know it? Go for it.'}</b><p>{game.submitted !== null ? 'Waiting for the big reveal…' : 'The faster you answer correctly, the more you score.'}</p></>}</div>
     <div className="answered-count"><Users size={16} />{game.players.filter(p => p.answered).length} of {game.players.length} answers locked</div>
    </div>}
   </section><aside className="room-sidebar"><div className="scorecard"><div className="sidebar-title"><Trophy size={20} /><h2>The leaderboard</h2></div><p>Friendly rivalry, live scores.</p><ol>{ranking.map((p, i) => <li className={p.id === game?.me ? 'you' : ''} key={p.id}><span className="rank">{i === 0 && p.score > 0 ? <Crown size={17} /> : i + 1}</span><span className="score-avatar">{avatars[p.avatar % 8]}</span><span className="score-name">{p.name}<small>{p.id === game?.me ? 'You' : 'In the rally'}{p.answered && isQuestion ? ' · Answered' : ''}</small></span><b>{p.score.toLocaleString()}</b></li>)}</ol>{!game && <p>Loading your crew…</p>}</div><div className="room-summary"><span className="tiny-label">ROOM CODE</span><div><strong>{session.code}</strong><button className="icon-button" aria-label="Copy invitation link" onClick={copyInvite}>{copied ? <Check size={18} /> : <Copy size={18} />}</button></div><p><Users size={15} />{game?.players.length ?? '…'} / 8 players</p></div><div className="tip"><Zap size={19} /><p><b>Every second counts.</b>Get it right for 500 points, plus up to 500 more for speed.</p></div></aside></div>
   {error && <div className="error" role="alert">{error}<button className="icon-button" aria-label="Dismiss error" onClick={() => setError('')}><X size={16} /></button></div>}
  </main>}
  <footer><span>A little competition. A lot of connection.</span><span>MADE TO PLAY TOGETHER <span className="footer-star">✳</span></span></footer>
  {scanning && <QRScanner onClose={() => setScanning(false)} onScan={roomCode => { setCode(roomCode); setScanned(true); setScanning(false); requestAnimationFrame(() => joinName.current?.focus()); }} />}
  {help && <div className="modal-backdrop" onClick={() => setHelp(false)}><section className="help-modal" role="dialog" aria-modal="true" aria-labelledby="help-title" onClick={e => e.stopPropagation()}><button autoFocus className="icon-button close-modal" aria-label="Close instructions" onClick={() => setHelp(false)}><X /></button><span className="big-emoji">⚡</span><h2 id="help-title">A little rally rundown.</h2><ol><li><b>Get together.</b> One host creates a room. Share the invite link, QR code, or six-character room code with 1–7 friends.</li><li><b>Join on your own screen.</b> Scan the host’s QR with your phone camera or the join form’s scanner. Enter a nickname, then the host starts when you’re ready.</li><li><b>Pick the right answer, fast.</b> Correct answers earn 500–1,000 points. Faster answers get more; wrong answers get zero. Your first answer is final.</li><li><b>Keep the rally going.</b> Each timed question is followed by a 6.5-second answer reveal. Highest total score wins; equal totals share the win.</li></ol><p>Keep this tab open to stay connected. Refreshing this tab restores your player. Rooms expire after 24 hours.</p><button className="button primary" onClick={() => setHelp(false)}>Got it. Game on!<Flag size={18} /></button></section></div>}
 </div>;
}
