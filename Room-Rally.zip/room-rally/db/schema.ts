import { integer, sqliteTable, text, primaryKey } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('rooms', {
 code: text('code').primaryKey(), host: text('host').notNull(), topic: text('topic').notNull(),
 questions: text('questions').notNull(), seconds: integer('seconds').notNull(),
 started: integer('started'), created: integer('created').notNull(),
});
export const players = sqliteTable('players', {
 token: text('token').primaryKey(), room: text('room').notNull().references(() => rooms.code, { onDelete: 'cascade' }),
 name: text('name').notNull(), avatar: integer('avatar').notNull(), joined: integer('joined').notNull(),
});
export const answers = sqliteTable('answers', {
 room: text('room').notNull().references(() => rooms.code, { onDelete: 'cascade' }),
 player: text('player').notNull().references(() => players.token, { onDelete: 'cascade' }),
 round: integer('round').notNull(), choice: integer('choice').notNull(),
 points: integer('points').notNull(), elapsed: integer('elapsed').notNull(),
}, (t) => [primaryKey({ columns: [t.room, t.player, t.round] })]);
