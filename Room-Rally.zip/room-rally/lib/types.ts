export type Player = { id: number; name: string; avatar: number; score: number; answered: boolean; lastPoints: number; correct: number };
export type GameState = {
 code: string; topic: string; seconds: number; total: number; host: boolean; me: number;
 phase: 'lobby' | 'countdown' | 'question' | 'reveal' | 'finished'; round: number;
 phaseEnds: number; serverNow: number; players: Player[]; submitted: number | null;
 question: { text: string; options: string[]; correct?: number; explanation?: string } | null;
};
export type Session = { code: string; token: string };
