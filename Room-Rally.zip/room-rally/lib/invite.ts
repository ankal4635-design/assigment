const ROOM_CODE = /^[A-Z2-9]{6}$/;

export function createInviteUrl(origin: string, code: string): string {
 if (!ROOM_CODE.test(code)) throw new Error('Invalid room code.');
 const url = new URL('/', origin);
 if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid game address.');
 url.searchParams.set('room', code);
 url.hash = 'join-room';
 return url.toString();
}

export function parseRoomInvite(value: string, origin: string): string {
 const trimmed = value.trim();
 if (ROOM_CODE.test(trimmed.toUpperCase())) return trimmed.toUpperCase();
 let url: URL;
 try { url = new URL(trimmed); } catch { throw new Error('This QR code is not a Room Rally invitation.'); }
 if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
  throw new Error('This QR code is not a Room Rally invitation.');
 }
 if (url.origin !== new URL(origin).origin) {
  throw new Error('This invite is for a different game server. Open it with your phone’s Camera app, or scan an invite from this server.');
 }
 const code = url.searchParams.get('room')?.toUpperCase() ?? '';
 if (url.pathname !== '/' || !ROOM_CODE.test(code)) throw new Error('This QR code does not contain a valid room code.');
 return code;
}
