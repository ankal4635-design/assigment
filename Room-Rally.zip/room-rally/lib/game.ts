import { bank, type Question } from './questions.ts';
import type { GameState } from './types.ts';
type Room = { code: string; host: string; topic: string; questions: string; seconds: number; started: number | null; created: number };
type Person = { token: string; name: string; avatar: number; joined: number };
const REVEAL = 6500;
export class GameError extends Error { status: number; constructor(message: string, status = 400) { super(message); this.status = status; } }
function requireValue(ok: unknown, message: string, status = 400): asserts ok { if (!ok) throw new GameError(message, status); }
function shuffle<T>(items: T[]): T[] {
 const a = [...items]; for (let i = a.length - 1; i > 0; i--) { const n = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1); [a[i], a[n]] = [a[n], a[i]]; } return a;
}
function selectQuestions(topic: string, count: number) {
 return shuffle(bank[topic]).slice(0, count).map(q => {
  const order = shuffle([0, 1, 2, 3]); return { ...q, options: order.map(i => q.options[i]), correct: order.indexOf(q.correct) };
 });
}
const makeToken = () => crypto.randomUUID() + crypto.randomUUID();
const cleanName = (value: unknown) => {
 requireValue(typeof value === 'string', 'Enter your player name.');
 const name = value.trim().replace(/\s+/g, ' ');
 requireValue(name.length >= 1 && name.length <= 20 && !/[\x00-\x1f]/.test(name), 'Use a name between 1 and 20 characters.'); return name;
};
export function timing(room: Room, now: number) {
 const questions: Question[] = JSON.parse(room.questions);
 if (room.started === null) return { phase: 'lobby' as const, round: 0, phaseEnds: 0 };
 if (now < room.started) return { phase: 'countdown' as const, round: 0, phaseEnds: room.started };
 const duration = room.seconds * 1000 + REVEAL;
 const round = Math.floor((now - room.started) / duration);
 if (round >= questions.length) return { phase: 'finished' as const, round: questions.length - 1, phaseEnds: 0 };
 const end = room.started + round * duration + room.seconds * 1000;
 return { phase: now < end ? 'question' as const : 'reveal' as const, round, phaseEnds: now < end ? end : end + REVEAL };
}
async function getRoom(db: D1Database, code: string, now: number) {
 const room = await db.prepare('SELECT * FROM rooms WHERE code = ?').bind(code).first<Room>();
 requireValue(room && room.created > now - 86400000, 'That room was not found or has expired. Ask your host for a new code.', 404); return room;
}
async function member(db: D1Database, code: string, token: string) {
 const person = await db.prepare('SELECT token, name, avatar, joined FROM players WHERE room = ? AND token = ?').bind(code, token).first<Person>();
 requireValue(person, 'Please rejoin this room.', 401); return person;
}
export async function getState(db: D1Database, code: string, token: string, now = Date.now()): Promise<GameState> {
 const room = await getRoom(db, code, now); await member(db, code, token);
 const t = timing(room, now); const qs: Question[] = JSON.parse(room.questions);
 const people = (await db.prepare('SELECT token, name, avatar, joined FROM players WHERE room = ? ORDER BY joined, token').bind(code).all<Person>()).results;
 const rows = (await db.prepare('SELECT player, round, points, choice FROM answers WHERE room = ?').bind(code).all<{ player: string; round: number; points: number; choice: number }>()).results;
 const reveal = t.phase === 'reveal' || t.phase === 'finished';
 const players = people.map((p, id) => {
  const visible = rows.filter(a => a.player === p.token && (a.round < t.round || reveal));
  return { id, name: p.name, avatar: p.avatar, score: visible.reduce((sum, a) => sum + a.points, 0),
   correct: visible.filter(a => a.points > 0).length, answered: rows.some(a => a.player === p.token && a.round === t.round),
   lastPoints: reveal ? (rows.find(a => a.player === p.token && a.round === t.round)?.points ?? 0) : 0 };
 });
 const current = qs[t.round]; const show = t.phase === 'question' || t.phase === 'reveal';
 return { code, topic: room.topic, seconds: room.seconds, total: qs.length, host: room.host === token,
  me: people.findIndex(p => p.token === token), ...t, serverNow: now, players,
  submitted: rows.find(a => a.player === token && a.round === t.round)?.choice ?? null,
  question: show ? { text: current.text, options: current.options, ...(reveal ? { correct: current.correct, explanation: current.explanation } : {}) } : null };
}
export async function gameAction(db: D1Database, input: Record<string, unknown>, token: string, now = Date.now()) {
 const action = input.action;
 if (action === 'create') {
  const name = cleanName(input.name); const topic = typeof input.topic === 'string' ? input.topic : 'Mixed bag';
  requireValue(Object.hasOwn(bank, topic), 'Choose a quiz topic.');
  const count = Number(input.rounds ?? 5); const seconds = Number(input.seconds ?? 20);
  requireValue([5, 10].includes(count) && [10, 20, 30].includes(seconds), 'Choose a supported game length and timer.');
  const credential = makeToken(); const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  await db.prepare('DELETE FROM rooms WHERE created < ?').bind(now - 86400000).run();
  for (let attempt = 0; attempt < 5; attempt++) {
   const code = Array.from(crypto.getRandomValues(new Uint8Array(6)), b => alphabet[b % alphabet.length]).join('');
   try {
    await db.batch([
     db.prepare('INSERT INTO rooms (code, host, topic, questions, seconds, created) VALUES (?, ?, ?, ?, ?, ?)').bind(code, credential, topic, JSON.stringify(selectQuestions(topic, count)), seconds, now),
     db.prepare('INSERT INTO players (token, room, name, avatar, joined) VALUES (?, ?, ?, 0, ?)').bind(credential, code, name, now),
    ]); return { code, token: credential };
   } catch (error) { if (!String(error).includes('UNIQUE constraint failed: rooms.code')) throw error; }
  } throw new GameError('Could not create a room. Please try again.', 503);
 }
 const code = typeof input.code === 'string' ? input.code.trim().toUpperCase() : '';
 requireValue(/^[A-Z2-9]{6}$/.test(code), 'Enter the six-character room code.');
 const room = await getRoom(db, code, now);
 if (action === 'join') {
  const name = cleanName(input.name); requireValue(room.started === null, 'This game has started. Ask your host to play again.');
  const credential = makeToken();
  // One atomic SQL statement enforces capacity and lobby status even for simultaneous joins.
  const result = await db.prepare(`INSERT INTO players (token, room, name, avatar, joined)
   SELECT ?, ?, ?, (SELECT COUNT(*) FROM players WHERE room = ?), ?
   WHERE (SELECT COUNT(*) FROM players WHERE room = ?) < 8
   AND EXISTS (SELECT 1 FROM rooms WHERE code = ? AND started IS NULL)
   AND NOT EXISTS (SELECT 1 FROM players WHERE room = ? AND lower(name) = lower(?))`)
   .bind(credential, code, name, code, now, code, code, code, name).run();
  requireValue(result.meta.changes === 1, 'Room full, name already taken, or game just started. Try a different name or ask the host.');
  return { code, token: credential };
 }
 await member(db, code, token); const t = timing(room, now);
 if (action === 'start' || action === 'replay') {
  requireValue(room.host === token, 'Only the host can start the game.', 403);
  if (action === 'start') {
   requireValue(t.phase === 'lobby', 'This game has already started.');
   const result = await db.prepare(`UPDATE rooms SET started = ? WHERE code = ? AND started IS NULL AND (SELECT COUNT(*) FROM players WHERE room = ?) >= 2`).bind(now + 4000, code, code).run();
   requireValue(result.meta.changes === 1, 'At least two players must join before you start.');
  } else {
   requireValue(t.phase === 'finished', 'Finish this game before playing again.');
   // Atomic reset; the started timestamp guards against duplicate replay requests.
   await db.batch([
    db.prepare('DELETE FROM answers WHERE room = ? AND EXISTS (SELECT 1 FROM rooms WHERE code = ? AND started = ?)').bind(code, code, room.started),
    db.prepare('UPDATE rooms SET started = NULL, questions = ? WHERE code = ? AND started = ?').bind(JSON.stringify(selectQuestions(room.topic, JSON.parse(room.questions).length)), code, room.started),
   ]);
  }
 } else if (action === 'answer') {
  requireValue(t.phase === 'question', 'The answer window has closed.');
  requireValue(input.round === t.round, 'The game has moved to another question.');
  const choice = input.choice; requireValue(Number.isInteger(choice) && Number(choice) >= 0 && Number(choice) < 4, 'Choose one answer.');
  const qs: Question[] = JSON.parse(room.questions);
  const start = room.started! + t.round * (room.seconds * 1000 + REVEAL);
  const elapsed = now - start;
  const points = choice === qs[t.round].correct ? Math.round(1000 - 500 * elapsed / (room.seconds * 1000)) : 0;
  await db.prepare('INSERT OR IGNORE INTO answers (room, player, round, choice, points, elapsed) VALUES (?, ?, ?, ?, ?, ?)').bind(code, token, t.round, choice, points, elapsed).run();
 } else throw new GameError('Unknown game action.');
 return getState(db, code, token, now);
}
