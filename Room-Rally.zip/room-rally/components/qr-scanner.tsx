'use client';
import { useEffect, useRef, useState } from 'react';
import { Camera, ImagePlus, QrCode, X } from 'lucide-react';
import { parseRoomInvite } from '@/lib/invite';

export function QRScanner({ onScan, onClose }: { onScan: (code: string) => void; onClose: () => void }) {
 const dialog = useRef<HTMLDialogElement>(null);
 const video = useRef<HTMLVideoElement>(null);
 const stream = useRef<MediaStream | null>(null);
 const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
 const alive = useRef(false);
 const fileInput = useRef<HTMLInputElement>(null);
 const [camera, setCamera] = useState<'off' | 'starting' | 'on'>('off');
 const [reading, setReading] = useState(false);
 const [error, setError] = useState('');
 const [cameraAvailable, setCameraAvailable] = useState(false);
 const [secure, setSecure] = useState(true);
 const lastInvalid = useRef('');
 const callbacks = useRef({ onScan, onClose }); callbacks.current = { onScan, onClose };
 function stopCamera() {
  if (timer.current) clearTimeout(timer.current);
  stream.current?.getTracks().forEach(track => track.stop()); stream.current = null;
  if (video.current) video.current.srcObject = null;
 }
 useEffect(() => {
  alive.current = true; dialog.current?.showModal();
  setSecure(window.isSecureContext); setCameraAvailable(!!navigator.mediaDevices?.getUserMedia);
  return () => { alive.current = false; stopCamera(); };
 }, []);
 function decode(value: string): boolean {
  try {
   const code = parseRoomInvite(value, location.origin);
   stopCamera(); callbacks.current.onScan(code); return true;
  } catch (err) {
   if (lastInvalid.current !== value) { setError(err instanceof Error ? err.message : 'Could not read this invitation.'); lastInvalid.current = value; }
   return false;
  }
 }
 async function startCamera() {
  if (camera !== 'off') return;
  setError(''); lastInvalid.current = ''; setCamera('starting');
  try {
   const { default: jsQR } = await import('jsqr');
   if (!alive.current) return;
   const media = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false });
   if (!alive.current) { media.getTracks().forEach(track => track.stop()); return; }
   stream.current = media;
   if (!video.current) { stopCamera(); return; }
   video.current.srcObject = media; await video.current.play();
   if (!alive.current) return;
   setCamera('on');
   const canvas = document.createElement('canvas');
   const context = canvas.getContext('2d', { willReadFrequently: true });
   if (!context) throw new Error('This browser cannot read camera images. Try uploading a QR image.');
   const scan = () => {
    if (!alive.current || !stream.current) return;
    const source = video.current;
    try { if (source && source.readyState >= 2 && source.videoWidth > 0) {
     const scale = Math.min(1, 720 / source.videoWidth);
     canvas.width = Math.round(source.videoWidth * scale); canvas.height = Math.round(source.videoHeight * scale);
     context.drawImage(source, 0, 0, canvas.width, canvas.height);
     const data = context.getImageData(0, 0, canvas.width, canvas.height);
     const qr = jsQR(data.data, data.width, data.height, { inversionAttempts: 'dontInvert' });
     if (qr && decode(qr.data)) return;
    } } catch {
     stopCamera(); setCamera('off'); setError('Could not read the camera image. Try uploading a QR image instead.'); return;
    }
    timer.current = setTimeout(scan, 140);
   };
   scan();
  } catch (err) {
   stopCamera();
   if (!alive.current) return;
   setCamera('off');
   const message = err instanceof DOMException && err.name === 'NotAllowedError'
    ? 'Camera access was not allowed. Allow it in your browser settings, upload a QR image, or type the room code.'
    : err instanceof DOMException && err.name === 'NotFoundError'
    ? 'No camera was found. You can upload a QR image or type the room code.'
    : 'Could not start the camera. Try uploading a QR image or type the room code.';
   setError(message);
  }
 }
 async function readImage(file: File) {
  if (reading) return;
  setReading(true); setError(''); lastInvalid.current = '';
  stopCamera(); setCamera('off');
  let objectUrl = '';
  try {
   if (file.size > 12 * 1024 * 1024) throw new Error('Choose an image smaller than 12 MB.');
   if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/bmp'].includes(file.type)) throw new Error('Choose a PNG, JPG, WebP, GIF, or BMP image of the QR code.');
   const { default: jsQR } = await import('jsqr');
   objectUrl = URL.createObjectURL(file);
   const image = new Image(); image.src = objectUrl; await image.decode();
   if (!alive.current) return;
   const canvas = document.createElement('canvas'); const scale = Math.min(1, 1800 / Math.max(image.naturalWidth, image.naturalHeight));
   canvas.width = Math.round(image.naturalWidth * scale); canvas.height = Math.round(image.naturalHeight * scale);
   const context = canvas.getContext('2d', { willReadFrequently: true });
   if (!context || !canvas.width || !canvas.height) throw new Error('Could not read this image. Try a clear screenshot of the QR code.');
   context.drawImage(image, 0, 0, canvas.width, canvas.height);
   const data = context.getImageData(0, 0, canvas.width, canvas.height); const qr = jsQR(data.data, data.width, data.height);
   if (!qr) throw new Error('No QR code found. Try a clearer image showing the whole code.');
   decode(qr.data);
  } catch (err) { if (alive.current) setError(err instanceof Error ? err.message : 'Could not read this image.'); }
  finally { if (objectUrl) URL.revokeObjectURL(objectUrl); if (alive.current) setReading(false); }
 }
 return <dialog className="qr-dialog" ref={dialog} aria-labelledby="scan-title" onClose={() => callbacks.current.onClose()} onClick={e => { if (e.target === e.currentTarget) callbacks.current.onClose(); }}>
  <section className="qr-dialog-inner" aria-labelledby="scan-title"><button type="button" className="icon-button qr-close" aria-label="Close QR scanner" onClick={onClose}><X size={21} /></button>
   <span className="scanner-symbol"><QrCode size={27} /></span><h2 id="scan-title">Scan. Join. Rally.</h2><p>Point your camera at the host’s room QR code, or choose a picture of it.</p>
   <video ref={video} autoPlay playsInline muted className={'scanner-video ' + (camera === 'on' ? 'visible' : '')} aria-label="Camera preview for scanning a room invitation" />
   {camera === 'on' ? <><p className="scanner-status" role="status">Looking for a room invitation…</p><button type="button" className="button subtle" onClick={() => { stopCamera(); setCamera('off'); }}>Stop camera</button></> : <button type="button" className="button primary" disabled={!cameraAvailable || camera === 'starting' || reading} onClick={startCamera}><Camera size={18} />{camera === 'starting' ? 'Starting camera…' : 'Use camera'}</button>}
   {!secure ? <p className="scanner-note">On this connection, use your phone’s Camera app to scan the host’s QR code, or upload a QR image below.</p> : !cameraAvailable && <p className="scanner-note">This browser does not offer camera access. Upload a QR image or enter the room code instead.</p>}
   <button type="button" className="button qr-upload" disabled={reading || camera === 'starting'} onClick={() => fileInput.current?.click()}><ImagePlus size={18} />{reading ? 'Reading image…' : 'Upload QR image'}</button>
   <input ref={fileInput} type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/bmp" hidden onChange={e => { const file = e.currentTarget.files?.[0]; e.currentTarget.value = ''; if (file) void readImage(file); }} />
   {error && <p className="scanner-error" role="alert">{error}</p>}
   <button type="button" className="scanner-manual" onClick={onClose}>Enter a room code instead</button>
  </section>
 </dialog>;
}
