'use client';
import { useEffect, useRef, useState } from 'react';
import { Download } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { createInviteUrl } from '@/lib/invite';

export function RoomQR({ code }: { code: string }) {
 const [origin, setOrigin] = useState('');
 const holder = useRef<HTMLDivElement>(null);
 useEffect(() => { setOrigin(location.origin); }, []);
 if (!origin) return null;
 const invite = createInviteUrl(origin, code);
 const localOnly = ['localhost', '127.0.0.1', '[::1]'].includes(new URL(origin).hostname);
 function download() {
  const canvas = holder.current?.querySelector('canvas'); if (!canvas) return;
  const link = document.createElement('a'); link.href = canvas.toDataURL('image/png'); link.download = 'room-rally-' + code + '.png'; link.click();
 }
 return <div className="room-qr">
  <div className="qr-image" ref={holder}><QRCodeCanvas value={invite} size={192} level="M" marginSize={4} fgColor="#252326" bgColor="#ffffff" role="img" aria-label={'Scan to join room ' + code} /></div>
  <b>Scan to join this room</b>
  <p>Open your phone’s Camera app and point it here.<br />Your room code will be filled in for you.</p>
  <a className="qr-invite-link" href={invite}>{invite}</a>
  <button type="button" className="qr-save" onClick={download}><Download size={13} /> Save QR code</button>
  {localOnly && <p className="qr-network-note">For phone testing, open this game’s local network address on the host computer first. A localhost link only opens on this computer.</p>}
 </div>;
}
