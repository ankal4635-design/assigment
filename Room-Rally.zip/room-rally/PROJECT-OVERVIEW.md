# Room Rally — Multiplayer Quiz Game

## Project cover page

**ROOM RALLY**  
*Good company. Great guesses.*

A Multiplayer Quiz Game for Friends and Family

**Developed using:** ChatGPT Work  
**Prepared by:** Dakota Melton  
**Institution:** Greenwood School  
**Date:** 30 October 2026

## Project description

Room Rally is an interactive multiplayer quiz game designed to bring friends and family together through friendly competition. Developed using ChatGPT Work, the project combines accessible gameplay with shared questions, timed answers, and a live leaderboard. It supports two to eight participants, allowing everyone to play on their own device while taking part in the same quiz session.

The game follows a familiar question and answer format inspired by Kahoot. One participant becomes the host, creates a room, selects a quiz topic, and chooses the game settings. Other players join using an invitation link, a six character room code, or a QR code displayed in the lobby. Each participant enters a nickname before the host starts the game, making the joining process straightforward.

Room Rally offers three built in quiz categories: Mixed Bag, Science, and World. Hosts can choose either five or ten questions and set answer windows of ten, twenty, or thirty seconds. These settings allow groups to adjust the pace according to their preferences. Questions and answer choices are shuffled on the server, helping rematches feel different and encouraging players to read carefully before selecting an option.

Speed and accuracy determine each player's score. A correct answer earns between five hundred and one thousand points, with faster responses receiving higher rewards. Incorrect answers earn no points, and the first submitted answer remains final. After each question, the game reveals the correct answer and provides a short explanation. This creates opportunities to learn while keeping the competition enjoyable. The participant with the highest total score wins, while equal totals share the victory.

A central feature is synchronization across participating devices. The server controls question timing, deadlines, answer validation, and scoring. Player screens regularly retrieve shared game information so that everyone follows the same sequence of questions and results. A countdown prepares participants before the opening question, while the leaderboard displays accumulated scores as the quiz progresses. Network conditions can affect response times, but scoring is calculated consistently by the server.

QR functionality makes the experience easier to access. Players can scan a room invitation using their phone's camera, use the scanner provided on the joining form, or upload an image containing the QR code. Scanning fills in the room code, after which the player enters a nickname and joins. Hosts can also download the QR image for sharing. The application handles QR decoding locally, and invitations contain the room address rather than private player credentials.

The project uses a responsive interface that adapts to different screen sizes. Cloudflare D1 stores rooms, players, and submitted answers, while automated tests check important multiplayer behavior, including duplicate submissions, room capacity, scoring, and host permissions. Hosts can organize rematches after viewing the final results. Room Rally demonstrates how web technologies can create an engaging group activity that combines entertainment, knowledge, quick thinking, and social interaction.

Prepared by Dakota Melton for Greenwood School, Room Rally provides a practical example of combining interface design, database management, software testing, and multiplayer programming within one complete project.

## Project link

https://room-rally-ankal.zestygull9.chatgpt.site

The hosted project is currently private.

## Local testing URL

http://192.168.100.158:5173/

Available on the same Wi-Fi while the server is running. The computer’s network address may change. See README.md for setup, database migrations, testing, and startup instructions.
